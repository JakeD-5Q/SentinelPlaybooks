# VirusTotal mass playbook deploy

Before running the script make sure to edit the parameters files to include the client abbreviation for the playbook name.