# Enrichment for all incidents


all these playbooks are to be added to an automation rule: **Enrich all incidents**

## Contents

- Enrich-Sentinel-Incident-AlienVault-OTX

    *must add the following role:* **Microsoft Sentinel Responder**

- Comment_RemediationSteps

    *must add the following role:* **Security Reader Role**

- Get-GeoFromIpAndTagIncident
